// config.js file for pm2

module.exports = {
    "apps": [
        {
        "name": "app",
        "script": "./app.js",
        "env": {
            "PORT": 5000,
            "NODE_ENV": "production",
            "MONGODB_URI": "mongodb+srv://avinash:FHLPojjNYxwWotHM@cluster0.ylo8n.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
            "JWT_SECRET": "eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTczNDE3NzM4NCwiaWF0IjoxNzM0MTc3Mzg0fQ.Iis3ih9SGYQg-2A4Khdjz9TEHpnenBYLEue0iX7SW98"
        }
        }
    ]
}
      