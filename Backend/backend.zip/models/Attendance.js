// models/Attendance.js
const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
    employeeId: { type: mongoose.Schema.Types.String, ref: 'Employee', required: true },
    date: { type: Date, required: true },
    hours: { type: Number },
  });
  
  module.exports = mongoose.model('Attendance', attendanceSchema);