const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  dob: { type: Date, required: true },
  passportNumber: { type: String, required: true },
  employeeId: { type: String, required: true, unique: true },
  designation: { type: String, required: true },
  currentAddress: { type: String, required: true },
  dateOfJoining: { type: Date, default: Date.now },
  profileUpdated: { type: Boolean, default: false },
  password: { type: String},
  role: { type: String, default: "employee" }
});

module.exports = mongoose.model('Employee', employeeSchema);
