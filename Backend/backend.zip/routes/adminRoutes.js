// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const Admin = require('../models/Admin');
const Employee = require('../models/Employee');
const Attendance = require('../models/Attendance');
const Holiday = require('../models/Holidays')
const MonthlyHours = require('../models/MonthlyHours');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { authenticateJWT } = require('../middleware/authMiddleware');
const moment = require('moment');

// Admin Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(404).json({ message: 'Admin not found' });

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign({ id: admin._id, role: admin.role }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.status(200).json({ token, role: admin.role, message: 'Admin login successful', admin });
  } catch (err) {
    res.status(500).json({ message: 'Error logging in' });
  }
});

// register
router.post("/create-admin", async (req, res) => {
  const { firstName, lastName, email, password, designation } = req.body;

  try {
    const emailExists = await Employee.findOne({ email });
    if (emailExists) {
      return res.status(400).json({ message: "Email already exists as an employee." });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newAdmin = new Admin({
      firstName,
      lastName,
      email,
      designation,
      password: hashedPassword,
      role: "admin",
    });

    await newAdmin.save();
    res.status(201).json({ message: "Admin created successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error creating admin", error });
  }
});

// Generate Attendance Report
router.get('/report', authenticateJWT, async (req, res) => {
  try {
    const employees = await Employee.find();
    const report = [];

    for (const employee of employees) {
      // Convert employee._id to a string for comparison
      const attendanceRecords = await Attendance.find({
        $or: [
          { employeeId: employee._id }, // If employeeId is ObjectId
          { employeeId: employee.employeeId } // If employeeId is a string (SOL2024002)
        ]
      });
      const attendanceMap = {};
      attendanceRecords.forEach(record => {
        const day = moment(record.date).format('MM-DD-YYYY');
        attendanceMap[day] = record.hours ? `${record.hours} hrs` : 'Absent';
      });


      const reportRow = {
        firstName: employee.firstName || "N/A",
        lastName: employee.lastName || "N/A",
        designation: employee.designation || "N/A",
        attendance: attendanceRecords,
      };

      report.push(reportRow);
    }

    res.status(200).json(report);
  } catch (err) {
    console.error('Error generating attendance report:', err);
    res.status(500).json({ message: 'Error generating report' });
  }
});

// Get Employee Details
router.get('/employees/:id', authenticateJWT,  async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    res.status(200).json(employee);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching employee details' });
  }
});

// View Working Hours and Attendance
router.get('/attendance/:employeeId', authenticateJWT, async (req, res) => {
  try {
    const attendanceRecords = await Attendance.find({ employeeId: req.params.employeeId });
    res.status(200).json(attendanceRecords);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching attendance records' });
  }
});

// Create an Employee
// create a default password for the employee as employeeId and send it to the employee's email address
router.post('/employee/register', authenticateJWT, async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      designation,
      currentAddress,
    } = req.body;

    // Check if the email already exists
    const existingEmployee = await Employee.findOne({ email });
    if (existingEmployee) {
      return res.status(400).json({ message: 'Employee with this email already exists' });
    }

    // Generate EmpId: SOL + CurrentYear + SequenceNumber
    const currentYear = new Date().getFullYear();
    const employeeCount = await Employee.countDocuments();
    const employeeId = `SOL${currentYear}${String(employeeCount + 1).padStart(3, '0')}`;

    const hashedPassword = await bcrypt.hash(employeeId, 10);

    const password= hashedPassword;

    // Create a new employee document
    const employee = new Employee({
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      employeeId,
      password,
      designation,
      currentAddress,
    });

    await employee.save();

    res.status(201).json({
      message: 'Employee registered successfully',
      employee: {
        employeeId,
        firstName,
        lastName,
        email
      }
    });

    // Send an email to the employee with the default password
    // const emailData = {
    //   to: email,
    //   subject: 'Welcome to the company!',
    //   text: `Your employee ID is ${employeeId} and your default password is ${employeeId}. Please change your password after logging in.`,
    // };
    // await sendEmail(emailData);
  } catch (error) {
    console.error('Error registering employee:', error);
    res.status(500).json({ message: 'An error occurred during registration. Please try again.' });
  }
});




// Delete an Employee
router.delete('/employees/:id', authenticateJWT, async (req, res) => {
  try {
    const employee = await Employee.findByIdAndDelete(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    // Delete associated attendance records
    await Attendance.deleteMany({ employeeId: req.params.id });

    res.status(200).json({ message: 'Employee and related attendance data deleted successfully' });
  } catch (err) {
    console.error('Error deleting employee:', err);
    res.status(500).json({ message: 'Error deleting employee' });
  }
});

// Update Employee Password
router.put('/employees/:id/password', authenticateJWT,  async (req, res) => {
  try {
    const { password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    const employee = await Employee.findByIdAndUpdate(
      req.params.id,
      { password: hashedPassword },
      { new: true }
    );

    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    res.status(200).json({ message: 'Password updated successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error updating password' });
  }
});


// Fetch All Employees
router.get('/employees', authenticateJWT,  async (req, res) => {
  try {
    const employees = await Employee.find();
    res.status(200).json(employees);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching employees' });
  }
});

router.get('/attendance', authenticateJWT,  async (req, res) => {
  try {
    const attendance = await Attendance.find();
    res.status(200).json(attendance);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching attendance' });
  }
});

router.get('/', authenticateJWT, async (req, res) => {
  try {
    const admins = await Admin.find();
    res.status(200).json(admins);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching admins' });
  }
});

// Update Employee Details
router.put('/employees/:id', authenticateJWT,  async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      designation,
      currentAddress,
    } = req.body;

    const employee = await Employee.findByIdAndUpdate(
      req.params.id,
      {
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      designation,
      currentAddress,
       },
      { new: true }
    );

    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    res.status(200).json({ message: 'Employee details updated successfully', employee });
  } catch (err) {
    res.status(500).json({ message: 'Error updating employee details' });
  }
});

router.patch('/password/:id', authenticateJWT, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    // Fetch admin by ID
    const admin = await Admin.findById(req.params.id);
    if (!admin) {
      return res.status(404).json({ message: 'Admin not found' });
    }

    // Check if current password matches
    const isMatch = await bcrypt.compare(currentPassword, admin.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password directly
    await Admin.updateOne({ _id: req.params.id }, { $set: { password: hashedPassword } });

    res.status(200).json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error('Error updating password:', err);
    res.status(500).json({ message: 'Error updating password' });
  }
});

// Get All Holidays
router.get('/holidays', authenticateJWT, async (req, res) => {
  try {
    const holidays = await Holiday.find();
    res.status(200).json(holidays);
  } catch (err) {
    console.error('Error fetching holidays:', err);
    res.status(500).json({ message: 'Error fetching holidays' });
  }
});

// Add a New Holiday
router.post('/holidays', authenticateJWT, async (req, res) => {
  try {
    const { name, date } = req.body;
    const holiday = new Holiday({ name, date });
    await holiday.save();

    res.status(201).json({ message: 'Holiday added successfully', holiday });
  } catch (err) {
    console.error('Error adding holiday:', err);
    res.status(500).json({ message: 'Error adding holiday' });
  }
});

// Edit an Existing Holiday
// Edit an Existing Holiday
router.patch('/holidays/:id', authenticateJWT, async (req, res) => {
  try {
    const { name, date } = req.body;

    // Check for a conflicting holiday
    const conflictingHoliday = await Holiday.findOne({ date, _id: { $ne: req.params.id } });

    // If a conflicting holiday exists, override it by deleting or updating it
    if (conflictingHoliday) {
      await Holiday.findByIdAndDelete(conflictingHoliday._id); // Delete the conflicting holiday
    }

    // Proceed to update the requested holiday
    const holiday = await Holiday.findByIdAndUpdate(
      req.params.id,
      { $set: { name, date } },
      { new: true }
    );

    if (!holiday) return res.status(404).json({ message: 'Holiday not found' });

    res.status(200).json({ message: 'Holiday updated successfully', holiday });
  } catch (err) {
    console.error('Error updating holiday:', err);
    res.status(500).json({ message: 'Error updating holiday' });
  }
});


// Delete a Holiday
router.delete('/holidays/:id', authenticateJWT, async (req, res) => {
  try {
    const holiday = await Holiday.findByIdAndDelete(req.params.id);
    if (!holiday) return res.status(404).json({ message: 'Holiday not found' });

    res.status(200).json({ message: 'Holiday deleted successfully' });
  } catch (err) {
    console.error('Error deleting holiday:', err);
    res.status(500).json({ message: 'Error deleting holiday' });
  }
});

router.get('/working-hours', authenticateJWT, async (req, res) => {
  try {
    const { month, year } = req.query;
    if (!month || !year) {
      return res.status(400).json({ message: 'Both "month" and "year" query parameters are required' });
    }


    const override = await MonthlyHours.findOne({ month, year });
    if (override) {
      return res.status(200).json({ month, year, hours: override.hours });
    }

    // Default calculation
    const daysInMonth = new Date(year, month, 0).getDate();

    const holidays = await Holiday.find({
      date: {
        $gte: new Date(year, month - 1, 1),
        $lte: new Date(year, month - 1, daysInMonth),
      },
    });

    const totalWorkingDays = Array.from({ length: daysInMonth }, (_, i) => i + 1).filter((day) => {
      const date = new Date(year, month - 1, day);
      const isWeekend = date.getDay() === 0 || date.getDay() === 6;
      const isHoliday = holidays.some((holiday) => holiday.date.toISOString().split('T')[0] === date.toISOString().split('T')[0]);
      return !isWeekend && !isHoliday;
    }).length;

    const totalHours = totalWorkingDays * 8;

    res.status(200).json({ month, year, hours: totalHours });
  } catch (err) {
    console.error('Error calculating working hours:', err.message, err.stack);
    res.status(500).json({ message: 'Error calculating working hours' });
  }
});



// Override Monthly Working Hours
router.put('/working-hours', authenticateJWT, async (req, res) => {
  try {
    const { month, year, hours } = req.body;
    if (!month || !year || !hours) {
      return res.status(400).json({ message: 'Month, year, and hours are required' });
    }

    const override = await MonthlyHours.findOneAndUpdate(
      { month, year },
      { hours },
      { new: true, upsert: true }
    );

    res.status(200).json({ message: 'Monthly working hours updated successfully', override });
  } catch (err) {
    console.error('Error overriding working hours:', err);
    res.status(500).json({ message: 'Error overriding working hours' });
  }
});


module.exports = router;
