const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { authenticateJWT } = require('../middleware/authMiddleware');

// Register Employee
router.post('/register', async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      designation,
      currentAddress,
    } = req.body;

    // Check if the email already exists
    const existingEmployee = await Employee.findOne({ email });
    if (existingEmployee) {
      return res.status(400).json({ message: 'Employee with this email already exists' });
    }

    // Generate EmpId: SOL + CurrentYear + Incremented Number
    const currentYear = new Date().getFullYear();
    const lastEmployee = await Employee.findOne().sort({ employeeId: -1 });
    let nextSequence = 1;

    if (lastEmployee && lastEmployee.employeeId) {
      const lastSequence = parseInt(lastEmployee.employeeId.slice(-3), 10);
      nextSequence = lastSequence + 1;
    }

    const employeeId = `SOL${currentYear}${String(nextSequence).padStart(3, '0')}`;
    
    // Use employeeId as the password for simplicity
    const plainPassword = employeeId;

    // Hash the password before saving to the database
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    // Create a new employee document
    const employee = new Employee({
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      employeeId,
      designation,
      currentAddress,
      password: hashedPassword,
    });

    await employee.save();

    // Include plain password in the response for display purposes
    res.status(201).json({
      message: 'Employee registered successfully',
      employee: {
        employeeId,
        firstName,
        lastName,
        email,
        plainPassword, // Send plain password
      },
    });
  } catch (error) {
    console.error('Error registering employee:', error);
    res.status(500).json({ message: 'An error occurred during registration. Please try again.' });
  }
});



// Other routes (Login, Update, Fetch Details) remain unchanged
// Employee Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const employee = await Employee.findOne({ email });
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    const isMatch = await bcrypt.compare(password, employee.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign({ id: employee._id, role: 'employee' }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });
    
    res.status(200).json({ token, message: 'Login successful', employee });
  } catch (err) {
    res.status(500).json({ message: 'Error logging in' });
  }
});

// Fetch Employee Profile (Authenticated)
router.get('/:id', authenticateJWT, async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    res.status(200).json(employee);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching employee profile' });
  }
});

// Update Employee Profile
router.put('/:id', authenticateJWT, async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      email,
      phone,
      dob,
      passportNumber,
      designation,
      currentAddress,
    } = req.body;

    const employee = await Employee.findByIdAndUpdate(
      req.params.id,
      { firstName, lastName, email, phone, dob, passportNumber, designation, currentAddress },
      { new: true }
    );

    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    res.status(200).json({ message: 'Employee details updated successfully', employee });
  } catch (err) {
    console.error('Error updating employee:', err);
    res.status(500).json({ message: 'Error updating employee details' });
  }
});

// Fetch All Employees
router.get('/employees', authenticateJWT, async (req, res) => {
  try {
    const employees = await Employee.find();
    res.status(200).json(employees);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching employees' });
  }
});

module.exports = router;
