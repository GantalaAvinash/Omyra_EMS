const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');
const moment = require('moment');

// Mark Attendance
router.post('/mark', async (req, res) => {
  try {
    const { employeeId, date, hours } = req.body;

    // Check if date is in the future
    const today = moment().startOf('day');
    const attendanceDate = moment(date).startOf('day');

    if (attendanceDate.isAfter(today)) {
      return res.status(400).json({ message: 'Cannot mark attendance for a future date' });
    }

    // Check if attendance for the date already exists
    const existingAttendance = await Attendance.findOne({ employeeId, date });
    if (existingAttendance) {
      return res.status(400).json({ message: 'Attendance already marked for this date' });
    }

    const attendance = new Attendance({
      employeeId,
      date,
      hours
    });

    await attendance.save();
    res.status(201).json({ message: 'Attendance marked successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error marking attendance' });
  }
});

// Get Attendance for Employee
router.get('/:employeeId', async (req, res) => {
  try {
    const attendanceRecords = await Attendance.find({ employeeId: req.params.employeeId });
    res.status(200).json(attendanceRecords);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching attendance records' });
  }
});

module.exports = router;
